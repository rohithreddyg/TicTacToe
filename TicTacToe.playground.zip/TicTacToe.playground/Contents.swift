//

import Foundation

enum Player: String {
    case X = "X"
    case O = "O"
}

struct TicTacToe {
    var board: [Player?] = Array(repeating: nil, count: 9)
    var currentPlayer: Player = .X
    var isGameFinished: Bool = false
    var winner: Player?
    
    mutating func makeMove(_ position: Int) -> Bool {
        guard position >= 0, position < 9, board[position] == nil, !isGameFinished else {
            return false
        }
        
        board[position] = currentPlayer
        if checkForWin(player: currentPlayer, position: position) {
            isGameFinished = true
            winner = currentPlayer
        } else if !board.contains(nil) {
            isGameFinished = true
        }
        
        currentPlayer = (currentPlayer == .X) ? .O : .X
        return true
    }
    
    private func checkForWin(player: Player, position: Int) -> Bool {
        let row = position / 3
        let col = position % 3
        
        // Check row
        if board[row*3] == player && board[row*3+1] == player && board[row*3+2] == player {
            return true
        }
        
        // Check column
        if board[col] == player && board[col+3] == player && board[col+6] == player {
            return true
        }
        
        // Check diagonals
        if position % 2 == 0 {
            if (board[0] == player && board[4] == player && board[8] == player) ||
               (board[2] == player && board[4] == player && board[6] == player) {
                return true
            }
        }
        
        return false
    }
    
    func printBoard() {
        print()
        for index in 0..<board.count {
            if let player = board[index] {
                print(player.rawValue, terminator: "")
            } else {
                print("_", terminator: "")
            }
            
            if index % 3 == 2 {
                print()
            } else {
                print("|", terminator: "")
            }
        }
    }
}


var game = TicTacToe()

print("Welcome to Tic Tac Toe!")
print("Player 1: X | Player 2: O")

func playTheTurn(_ position: Int) {
    if !game.isGameFinished {
        game.printBoard()
        print("\(game.currentPlayer.rawValue)'s turn. Enter your move (0-8): ", terminator: "")
        if game.makeMove(position) {
            if game.isGameFinished {
                game.printBoard()
                if let winner = game.winner {
                    print("Game over! \(winner.rawValue) wins!")
                } else {
                    print("Game is Draw!")
                }
            }
        } else {
            print("Invalid input! Please enter a number between 0 and 8.")
        }
    } else {
        print("Game over!!!")
    }
}

playTheTurn(4)
playTheTurn(0)
playTheTurn(1)
playTheTurn(3)
playTheTurn(5)
playTheTurn(2)
playTheTurn(8)
playTheTurn(7)
playTheTurn(6)

